# =============================================================================
# SHINY APP COMPLETA - ANÁLISIS ESPACIAL PUNO1
# =============================================================================

library(shiny)
library(shinydashboard)
library(spdep)
library(sf)
library(ggplot2)
library(dplyr)
library(leaflet)
library(DT)

# UI --------------------------------------------------------------------------
ui <- dashboardPage(
  skin = "blue",
  
  dashboardHeader(
    title = "ANÁLISIS ESPACIAL PUNO1",
    titleWidth = 300
  ),
  
  dashboardSidebar(
    width = 300,
    sidebarMenu(
      id = "tabs",
      menuItem("📊 Dashboard Principal", tabName = "dashboard", icon = icon("dashboard")),
      menuItem("🗺️ Mapas Interactivos", tabName = "mapas", icon = icon("map")),
      menuItem("📋 Resultados", tabName = "resultados", icon = icon("table")),
      menuItem("ℹ️ Información", tabName = "info", icon = icon("info-circle"))
    ),
    
    # Panel de controles que aparece en todos los tabs
    conditionalPanel(
      'input.tabs !== "info"',
      hr(),
      h4("Controles de Análisis", style = "padding: 10px;"),
      sliderInput("umbral_distancia", "Umbral de Distancia:", 
                  min = 0.1, max = 2, value = 0.5, step = 0.1),
      selectInput("tipo_vecindad", "Tipo de Vecindad:",
                  choices = c("Distancia" = "distancia",
                              "K-Vecinos" = "kvecinos"),
                  selected = "distancia"),
      actionButton("calcular", "🔄 Calcular Análisis", 
                   class = "btn-primary", width = "100%")
    )
  ),
  
  dashboardBody(
    tags$head(
      tags$style(HTML("
        .content-wrapper, .right-side {
          background-color: #f4f4f4;
        }
        .box {
          box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
      "))
    ),
    
    tabItems(
      # Dashboard tab
      tabItem(
        tabName = "dashboard",
        h2("Dashboard de Análisis Espacial - Superficie PUNO1"),
        
        fluidRow(
          # Value boxes
          valueBoxOutput("moran_box", width = 3),
          valueBoxOutput("geary_box", width = 3),
          valueBoxOutput("hotspots_box", width = 3),
          valueBoxOutput("coldspots_box", width = 3)
        ),
        
        fluidRow(
          box(
            title = "📈 Diagrama de Dispersión de Moran", 
            status = "primary", solidHeader = TRUE,
            width = 6,
            plotOutput("moran_plot", height = 400)
          ),
          box(
            title = "📊 Distribución de la Superficie", 
            status = "primary", solidHeader = TRUE,
            width = 6,
            plotOutput("histograma", height = 400)
          )
        ),
        
        fluidRow(
          box(
            title = "🧩 Clusters LISA", 
            status = "info", solidHeader = TRUE,
            width = 6,
            plotOutput("lisa_plot", height = 400)
          ),
          box(
            title = "🔥 Hotspots y Coldspots", 
            status = "info", solidHeader = TRUE,
            width = 6,
            plotOutput("hotspots_plot", height = 400)
          )
        )
      ),
      
      # Mapas tab
      tabItem(
        tabName = "mapas",
        h2("Mapas Interactivos - Análisis Espacial"),
        
        fluidRow(
          box(
            title = "🗺️ Mapa Interactivo", 
            status = "success", solidHeader = TRUE,
            width = 12,
            leafletOutput("mapa_leaflet", height = 600)
          )
        ),
        
        fluidRow(
          box(
            title = "🎨 Configuración del Mapa", 
            width = 12,
            selectInput("tipo_mapa", "Seleccionar Capa:",
                        choices = c("Superficie (ha)" = "superficie",
                                    "Clusters LISA" = "lisa",
                                    "Hotspots/Coldspots" = "hotspots"),
                        selected = "superficie"),
            sliderInput("tamanio_puntos", "Tamaño de Puntos:", 
                        min = 3, max = 10, value = 6)
          )
        )
      ),
      
      # Resultados tab
      tabItem(
        tabName = "resultados",
        h2("Resultados y Datos del Análisis"),
        
        fluidRow(
          box(
            title = "📋 Resumen Estadístico", 
            status = "warning", solidHeader = TRUE,
            width = 12,
            tableOutput("tabla_resumen")
          )
        ),
        
        fluidRow(
          box(
            title = "📊 Estadísticas Descriptivas", 
            width = 6,
            verbatimTextOutput("estadisticas_descriptivas")
          ),
          box(
            title = "🔍 Significancia Estadística", 
            width = 6,
            verbatimTextOutput("significancia")
          )
        ),
        
        fluidRow(
          box(
            title = "💾 Datos Espaciales Completos", 
            status = "primary", solidHeader = TRUE,
            width = 12,
            downloadButton("descargar_csv", "📥 Descargar CSV", 
                           class = "btn-success"),
            downloadButton("descargar_shp", "📥 Descargar Shapefile",
                           class = "btn-info"),
            br(), br(),
            DT::dataTableOutput("tabla_datos")
          )
        )
      ),
      
      # Información tab
      tabItem(
        tabName = "info",
        h2("ℹ️ Información del Proyecto"),
        
        fluidRow(
          box(
            title = "📚 Acerca del Análisis", 
            width = 12, status = "info",
            h3("Análisis Espacial de Superficie - PUNO1"),
            p("Esta aplicación realiza un análisis espacial completo sobre la variable de superficie (P104_SUP_ha) de la base de datos PUNO1."),
            br(),
            h4("📈 Métodos Implementados:"),
            tags$ul(
              tags$li("✅ Matrices de Pesos Espaciales"),
              tags$li("✅ Estadístico I de Moran (Global y Local)"),
              tags$li("✅ Estadístico C de Geary"),
              tags$li("✅ Análisis de Hotspots (Getis-Ord Gi*)")
            ),
            br(),
            h4("🎯 Interpretación:"),
            p("• Moran I > 0: Autocorrelación espacial positiva (valores similares se agrupan)"),
            p("• Geary C < 1: Confirma autocorrelación positiva"),
            p("• Hotspots: Áreas con valores significativamente altos"),
            p("• Coldspots: Áreas con valores significativamente bajos")
          )
        )
      )
    )
  )
)

# Server ----------------------------------------------------------------------
server <- function(input, output, session) {
  
  # Reactive data - Simulación de datos PUNO1
  datos_reactivos <- reactive({
    input$calcular  # Depende del botón calcular
    
    # Crear datos de ejemplo PUNO1
    set.seed(123)
    n_regiones <- 50
    
    # Coordenadas simuladas de Puno
    coords <- cbind(
      longitud = -70 + runif(n_regiones, -1, 1),
      latitud = -15 + runif(n_regiones, -1, 1)
    )
    
    # Crear variable superficie con autocorrelación espacial
    superficie <- numeric(n_regiones)
    superficie[1] <- rnorm(1, 100, 20)
    
    for(i in 2:n_regiones) {
      distancias <- sqrt((coords[i,1] - coords[1:(i-1),1])^2 + 
                           (coords[i,2] - coords[1:(i-1),2])^2)
      vecino <- which.min(distancias)
      superficie[i] <- 0.7 * superficie[vecino] + rnorm(1, 30, 10)
    }
    
    # Asegurar valores positivos
    superficie <- abs(superficie)
    
    # Crear dataframe
    datos <- data.frame(
      id = 1:n_regiones,
      CCDI = sprintf("%06d", 1:n_regiones),
      NOMBREDI = paste("Distrito", 1:n_regiones),
      P104_SUP_ha = round(superficie, 2),
      longitud = coords[,1],
      latitud = coords[,2]
    )
    
    # Crear objeto espacial
    puno1_sf <- st_as_sf(datos, coords = c("longitud", "latitud"), crs = 4326)
    
    # Crear matrices de pesos
    coords_matrix <- st_coordinates(puno1_sf)
    
    if(input$tipo_vecindad == "distancia") {
      nb <- dnearneigh(coords_matrix, 0, input$umbral_distancia)
    } else {
      nb <- knn2nb(knearneigh(coords_matrix, k = 5))
    }
    
    w_std <- nb2listw(nb, style = "W", zero.policy = TRUE)
    w_binaria <- nb2listw(nb, style = "B", zero.policy = TRUE)
    
    # Calcular Moran Global
    moran_global <- moran.test(puno1_sf$P104_SUP_ha, w_std, zero.policy = TRUE)
    
    # Calcular Moran Local (LISA)
    local_moran <- localmoran(puno1_sf$P104_SUP_ha, w_std, zero.policy = TRUE)
    puno1_sf$lm_i <- local_moran[,1]
    puno1_sf$lm_pval <- local_moran[,5]
    
    # Clasificar clusters LISA
    media_superficie <- mean(puno1_sf$P104_SUP_ha)
    puno1_sf$lisa_cluster <- "No significativo"
    puno1_sf$lisa_cluster[puno1_sf$lm_pval < 0.05 & puno1_sf$lm_i > 0 & 
                            puno1_sf$P104_SUP_ha > media_superficie] <- "Alto-Alto"
    puno1_sf$lisa_cluster[puno1_sf$lm_pval < 0.05 & puno1_sf$lm_i > 0 & 
                            puno1_sf$P104_SUP_ha < media_superficie] <- "Bajo-Bajo"
    puno1_sf$lisa_cluster[puno1_sf$lm_pval < 0.05 & puno1_sf$lm_i < 0 & 
                            puno1_sf$P104_SUP_ha > media_superficie] <- "Alto-Bajo"
    puno1_sf$lisa_cluster[puno1_sf$lm_pval < 0.05 & puno1_sf$lm_i < 0 & 
                            puno1_sf$P104_SUP_ha < media_superficie] <- "Bajo-Alto"
    
    # Calcular Geary
    geary_global <- geary.test(puno1_sf$P104_SUP_ha, w_std, zero.policy = TRUE)
    
    # Calcular Hotspots
    gi_star <- localG(puno1_sf$P104_SUP_ha, w_binaria, zero.policy = TRUE)
    puno1_sf$gi_star <- as.numeric(gi_star)
    puno1_sf$gi_pval <- 2 * pnorm(-abs(puno1_sf$gi_star))
    
    puno1_sf$hotspot_cluster <- "No significativo"
    puno1_sf$hotspot_cluster[puno1_sf$gi_pval < 0.05 & puno1_sf$gi_star > 0] <- "Hotspot"
    puno1_sf$hotspot_cluster[puno1_sf$gi_pval < 0.05 & puno1_sf$gi_star < 0] <- "Coldspot"
    
    # Devolver resultados
    list(
      datos = puno1_sf,
      moran = moran_global,
      geary = geary_global,
      w_std = w_std,
      nb = nb
    )
  })
  
  # Value Boxes
  output$moran_box <- renderValueBox({
    datos <- datos_reactivos()
    if(is.null(datos)) return(valueBox("N/A", "Moran I", icon = icon("chart-line"), color = "red"))
    
    moran_i <- round(datos$moran$estimate[1], 4)
    sig <- datos$moran$p.value < 0.05
    color <- ifelse(sig, "green", "red")
    icono <- ifelse(sig, "thumbs-up", "thumbs-down")
    
    valueBox(
      moran_i, 
      paste("Moran I", ifelse(sig, "(Sig.)", "(No Sig.)")),
      icon = icon(icono), 
      color = color
    )
  })
  
  output$geary_box <- renderValueBox({
    datos <- datos_reactivos()
    if(is.null(datos)) return(valueBox("N/A", "Geary C", icon = icon("chart-bar"), color = "red"))
    
    geary_c <- round(datos$geary$estimate[1], 4)
    sig <- datos$geary$p.value < 0.05
    color <- ifelse(sig, "green", "red")
    icono <- ifelse(sig, "thumbs-up", "thumbs-down")
    
    valueBox(
      geary_c, 
      paste("Geary C", ifelse(sig, "(Sig.)", "(No Sig.)")),
      icon = icon(icono), 
      color = color
    )
  })
  
  output$hotspots_box <- renderValueBox({
    datos <- datos_reactivos()
    if(is.null(datos)) return(valueBox("N/A", "Hotspots", icon = icon("fire"), color = "red"))
    
    n_hotspots <- sum(datos$datos$hotspot_cluster == "Hotspot")
    
    valueBox(
      n_hotspots, "Hotspots Identificados",
      icon = icon("fire"), color = "orange"
    )
  })
  
  output$coldspots_box <- renderValueBox({
    datos <- datos_reactivos()
    if(is.null(datos)) return(valueBox("N/A", "Coldspots", icon = icon("snowflake"), color = "red"))
    
    n_coldspots <- sum(datos$datos$hotspot_cluster == "Coldspot")
    
    valueBox(
      n_coldspots, "Coldspots Identificados",
      icon = icon("snowflake"), color = "blue"
    )
  })
  
  # Gráficos
  output$moran_plot <- renderPlot({
    datos <- datos_reactivos()
    if(is.null(datos)) return(NULL)
    
    x_std <- scale(datos$datos$P104_SUP_ha)
    w_x <- lag.listw(datos$w_std, x_std, zero.policy = TRUE)
    
    plot(x_std, w_x, 
         xlab = "Superficie Estandarizada (ha)", 
         ylab = "Rezago Espacial",
         main = paste("Diagrama de Dispersión de Moran\nI =", 
                      round(datos$moran$estimate[1], 3)),
         pch = 19, col = "blue", cex = 1.2)
    abline(h = 0, v = 0, lty = 2, col = "gray")
    abline(lm(w_x ~ x_std), col = "red", lwd = 2)
    grid()
  })
  
  output$histograma <- renderPlot({
    datos <- datos_reactivos()
    if(is.null(datos)) return(NULL)
    
    ggplot(datos$datos, aes(x = P104_SUP_ha)) +
      geom_histogram(fill = "steelblue", alpha = 0.8, bins = 20, color = "white") +
      labs(title = "Distribución de Superficies Agrícolas",
           x = "Superficie (ha)", y = "Frecuencia") +
      theme_minimal() +
      theme(plot.title = element_text(hjust = 0.5, face = "bold"))
  })
  
  output$lisa_plot <- renderPlot({
    datos <- datos_reactivos()
    if(is.null(datos)) return(NULL)
    
    ggplot(datos$datos) +
      geom_sf(aes(fill = lisa_cluster), size = 2, shape = 21, color = "white") +
      scale_fill_manual(
        name = "Clusters LISA",
        values = c("Alto-Alto" = "#d73027", "Bajo-Bajo" = "#4575b4",
                   "Alto-Bajo" = "#fdae61", "Bajo-Alto" = "#91bfdb",
                   "No significativo" = "#f0f0f0")
      ) +
      labs(title = "Clusters de Autocorrelación Local (LISA)") +
      theme_void() +
      theme(plot.title = element_text(hjust = 0.5, face = "bold"))
  })
  
  output$hotspots_plot <- renderPlot({
    datos <- datos_reactivos()
    if(is.null(datos)) return(NULL)
    
    ggplot(datos$datos) +
      geom_sf(aes(fill = hotspot_cluster), size = 2, shape = 21, color = "white") +
      scale_fill_manual(
        name = "Hotspots/Coldspots",
        values = c("Hotspot" = "#b2182b", "Coldspot" = "#2166ac",
                   "No significativo" = "#f0f0f0")
      ) +
      labs(title = "Hotspots y Coldspots (Getis-Ord Gi*)") +
      theme_void() +
      theme(plot.title = element_text(hjust = 0.5, face = "bold"))
  })
  
  # Mapa Leaflet
  output$mapa_leaflet <- renderLeaflet({
    datos <- datos_reactivos()
    if(is.null(datos)) return(NULL)
    
    # Preparar datos para el mapa
    map_data <- datos$datos
    
    # Definir paleta según tipo de mapa
    if(input$tipo_mapa == "superficie") {
      pal <- colorNumeric("viridis", map_data$P104_SUP_ha)
      valores <- map_data$P104_SUP_ha
      titulo <- "Superficie (ha)"
    } else if(input$tipo_mapa == "lisa") {
      pal <- colorFactor(
        c("#d73027", "#4575b4", "#fdae61", "#91bfdb", "#f0f0f0"),
        domain = map_data$lisa_cluster
      )
      valores <- map_data$lisa_cluster
      titulo <- "Clusters LISA"
    } else {
      pal <- colorFactor(
        c("#b2182b", "#2166ac", "#f0f0f0"),
        domain = map_data$hotspot_cluster
      )
      valores <- map_data$hotspot_cluster
      titulo <- "Hotspots/Coldspots"
    }
    
    # Crear mapa
    leaflet(map_data) %>%
      addProviderTiles(providers$CartoDB.Positron) %>%
      addCircleMarkers(
        lng = st_coordinates(map_data)[,1],
        lat = st_coordinates(map_data)[,2],
        color = ~pal(valores),
        fillOpacity = 0.8,
        radius = input$tamanio_puntos,
        stroke = TRUE,
        weight = 1,
        popup = ~paste(
          "<b>Distrito:</b> ", NOMBREDI, "<br>",
          "<b>Superficie:</b> ", round(P104_SUP_ha, 2), " ha<br>",
          "<b>Cluster LISA:</b> ", lisa_cluster, "<br>",
          "<b>Hotspot:</b> ", hotspot_cluster
        )
      ) %>%
      addLegend(
        position = "bottomright",
        pal = pal,
        values = valores,
        title = titulo,
        opacity = 1
      )
  })
  
  # Tablas y resultados
  output$tabla_resumen <- renderTable({
    datos <- datos_reactivos()
    if(is.null(datos)) return(NULL)
    
    data.frame(
      Métrica = c("Número de Observaciones", "Superficie Promedio (ha)", 
                  "Superficie Mínima (ha)", "Superficie Máxima (ha)",
                  "Moran I", "Geary C", "Hotspots", "Coldspots"),
      Valor = c(
        nrow(datos$datos),
        round(mean(datos$datos$P104_SUP_ha), 2),
        round(min(datos$datos$P104_SUP_ha), 2),
        round(max(datos$datos$P104_SUP_ha), 2),
        round(datos$moran$estimate[1], 4),
        round(datos$geary$estimate[1], 4),
        sum(datos$datos$hotspot_cluster == "Hotspot"),
        sum(datos$datos$hotspot_cluster == "Coldspot")
      )
    )
  }, bordered = TRUE, striped = TRUE)
  
  output$estadisticas_descriptivas <- renderPrint({
    datos <- datos_reactivos()
    if(is.null(datos)) return("Cargando datos...")
    
    summary(datos$datos$P104_SUP_ha)
  })
  
  output$significancia <- renderPrint({
    datos <- datos_reactivos()
    if(is.null(datos)) return("Cargando datos...")
    
    cat("Moran I - p-value:", datos$moran$p.value, 
        ifelse(datos$moran$p.value < 0.05, "(SIGNIFICATIVO)", "(NO SIGNIFICATIVO)"),
        "\n\n")
    cat("Geary C - p-value:", datos$geary$p.value,
        ifelse(datos$geary$p.value < 0.05, "(SIGNIFICATIVO)", "(NO SIGNIFICATIVO)"))
  })
  
  output$tabla_datos <- DT::renderDataTable({
    datos <- datos_reactivos()
    if(is.null(datos)) return(NULL)
    
    DT::datatable(
      st_drop_geometry(datos$datos) %>%
        select(id, CCDI, NOMBREDI, P104_SUP_ha, lisa_cluster, hotspot_cluster),
      options = list(
        pageLength = 10,
        scrollX = TRUE,
        dom = 'Bfrtip',
        buttons = c('copy', 'csv', 'excel')
      ),
      rownames = FALSE
    )
  })
  
  # Descargas
  output$descargar_csv <- downloadHandler(
    filename = function() {
      paste0("PUNO1_analisis_espacial_", Sys.Date(), ".csv")
    },
    content = function(file) {
      datos <- datos_reactivos()
      if(!is.null(datos)) {
        write.csv(st_drop_geometry(datos$datos), file, row.names = FALSE)
      }
    }
  )
  
  output$descargar_shp <- downloadHandler(
    filename = function() {
      paste0("PUNO1_datos_espaciales_", Sys.Date(), ".zip")
    },
    content = function(file) {
      datos <- datos_reactivos()
      if(!is.null(datos)) {
        temp_dir <- tempdir()
        shapefile_path <- file.path(temp_dir, "puno1_analisis")
        st_write(datos$datos, paste0(shapefile_path, ".shp"), delete_dsn = TRUE)
        zip(file, list.files(temp_dir, pattern = "puno1_analisis", full.names = TRUE))
      }
    }
  )
}

# Run the application 
shinyApp(ui = ui, server = server)


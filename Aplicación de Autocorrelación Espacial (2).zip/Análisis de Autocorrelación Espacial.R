# ANÁLISIS COMPARATIVO COMPLETO DE AUTOCORRELACIÓN ESPACIAL (CORREGIDO)
# Replicación metodológica de los tres estudios: Yan, Lambadri y Hu

# 0. Paquetes necesarios ----
library(sf)
library(spdep)
library(ggplot2)
library(reshape2)
library(kableExtra)
library(sp)
library(GWmodel)
library(dplyr)
library(tidyr)
library(viridis)

# Configurar tema ggplot2
theme_set(theme_minimal())

# 1. FUNCIONES AUXILIARES ----
crear_matriz_pesos <- function(geometrias, tipo = "vecindad", k = 5) {
  # Crear matriz de pesos espaciales según diferentes criterios
  coords <- st_centroid(st_geometry(geometrias))
  coords_mat <- st_coordinates(coords)
  
  if(tipo == "vecindad") {
    # Matriz de contigüidad por vecindad Queen (polígonos)
    nb <- poly2nb(geometrias, queen = TRUE)
    pesos <- nb2listw(nb, style = "W", zero.policy = TRUE)
  } else if(tipo == "knn") {
    # K vecinos más cercanos
    nb <- knn2nb(knearneigh(coords_mat, k = k))
    pesos <- nb2listw(nb, style = "W", zero.policy = TRUE)
  } else if(tipo == "distancia") {
    # Matriz de pesos por distancia inversa (dentro de un rango)
    # Ajusta el umbral máximo (here 3 unidades) según escala de tus datos
    nb <- dnearneigh(coords_mat, 0, 3)
    distancias <- nbdists(nb, coords_mat)
    pesos_inv <- lapply(distancias, function(x) if(length(x)>0) 1/x else numeric(0))
    pesos <- nb2listw(nb, glist = pesos_inv, style = "W", zero.policy = TRUE)
  } else {
    nb <- poly2nb(geometrias, queen = TRUE)
    pesos <- nb2listw(nb, style = "W", zero.policy = TRUE)
  }
  
  return(pesos)
}

calcular_moran_global <- function(variable, pesos) {
  # Calcular índice de Moran global con significancia (usa randomización)
  resultado <- moran.test(variable, pesos, randomisation = TRUE, zero.policy = TRUE)
  return(resultado)
}

calcular_lisa <- function(variable, pesos) {
  # Calcular indicadores locales de asociación espacial (LISA)
  # localmoran devuelve una matriz con I, E(I), Var(I), z, Pr(z)
  lisa <- localmoran(variable, pesos, zero.policy = TRUE)
  return(lisa)
}

calcular_getis_ord <- function(variable, geometrias, k = 5) {
  # Calcular estadística Getis-Ord Gi*
  coords <- st_coordinates(st_centroid(geometrias))
  nb <- knn2nb(knearneigh(coords, k = k))
  listw <- nb2listw(nb, style = "B", zero.policy = TRUE)
  gi <- localG(variable, listw, zero.policy = TRUE)
  return(as.numeric(gi))
}

# 2. CREAR GEOMETRÍA BASE ----
crear_geometria_base <- function() {
  # Crear geometría ficticia (grid regular 10x10 en [0,10]x[0,10])
  bbox <- st_bbox(c(xmin = 0, xmax = 10, ymin = 0, ymax = 10))
  grid <- st_make_grid(st_as_sfc(bbox), n = c(10, 10), what = "polygons")
  grid_sf <- st_sf(geometry = grid)
  grid_sf$id <- seq_len(nrow(grid_sf))
  return(grid_sf)
}

# 3. SIMULACIÓN DE DATOS SEGÚN LOS ESTUDIOS ----
set.seed(123)  # Para reproducibilidad

# 3.1 Estudio de Vegetación (Yan et al.)
simular_datos_vegetacion <- function() {
  grid_sf <- crear_geometria_base()
  
  coords <- st_coordinates(st_centroid(grid_sf))
  grid_sf$longitud <- coords[,1]
  grid_sf$latitud <- coords[,2]
  
  # Simular NDVI con autocorrelación espacial fuerte
  grid_sf$ndvi <- 0.3 + 0.5 * (1 - grid_sf$longitud / max(grid_sf$longitud)) + 
    rnorm(nrow(grid_sf), 0, 0.1)
  
  # Simular variables climáticas
  grid_sf$precipitacion <- grid_sf$ndvi * 0.8 + rnorm(nrow(grid_sf), 0, 0.05)
  grid_sf$temperatura <- 25 - grid_sf$ndvi * 10 + rnorm(nrow(grid_sf), 0, 0.5)
  grid_sf$humedad <- grid_sf$ndvi * 0.6 + rnorm(nrow(grid_sf), 0.3, 0.1)
  
  return(grid_sf)
}

# 3.2 Estudio Costero (Lambadri et al.)
simular_datos_costeros <- function() {
  datos <- crear_geometria_base()
  coords <- st_coordinates(st_centroid(datos))
  
  # Simular índice de exposición costera (más alto en latitudes bajas)
  datos$exposicion <- ifelse(coords[,2] < 5, 
                             runif(sum(coords[,2] < 5), 0.7, 0.9),
                             runif(sum(coords[,2] >= 5), 0.2, 0.4))
  
  # Añadir autocorrelación espacial mediante lag
  pesos <- crear_matriz_pesos(datos, tipo = "vecindad")
  datos$exposicion <- as.vector(0.7 * datos$exposicion + 
                                  0.3 * lag.listw(pesos, datos$exposicion, zero.policy = TRUE))
  
  # Variables adicionales costeras
  datos$elevacion <- ifelse(coords[,2] < 5, 
                            runif(sum(coords[,2] < 5), 0.1, 0.5),
                            runif(sum(coords[,2] >= 5), 1.0, 2.0))
  
  datos$habitat_natural <- 1 - datos$exposicion * 0.7 + rnorm(nrow(datos), 0, 0.1)
  
  return(datos)
}

# 3.3 Estudio Epidemiológico (Hu et al.)
simular_datos_epidemiologicos <- function() {
  datos <- crear_geometria_base()
  coords <- st_coordinates(st_centroid(datos))
  
  # Simular incidencia de paperas con patrones regionales (eje x)
  datos$incidencia_paperas <- ifelse(coords[,1] < 3, 
                                     rnorm(sum(coords[,1] < 3), 0.8, 0.1),
                                     rnorm(sum(coords[,1] >= 3), 0.3, 0.1))
  
  # Simular factores asociados
  datos$tasa_dependencia_infantil <- datos$incidencia_paperas * 0.6 + 
    rnorm(nrow(datos), 0.5, 0.1)
  
  datos$pib_per_capita <- 1 - datos$incidencia_paperas * 0.4 + 
    rnorm(nrow(datos), 0.5, 0.1)
  
  datos$cobertura_vacunacion <- 0.8 - datos$incidencia_paperas * 0.5 + 
    rnorm(nrow(datos), 0, 0.1)
  
  datos$densidad_poblacional <- datos$incidencia_paperas * 0.7 + 
    rnorm(nrow(datos), 0.3, 0.1)
  
  return(datos)
}

# 4. ANÁLISIS COMPARATIVO BÁSICO ----
realizar_analisis_comparativo <- function() {
  
  resultados_comparativos <- list()
  
  cat("=== ANÁLISIS DE VEGETACIÓN (Yan et al. 2025) ===\n")
  datos_vegetacion <- simular_datos_vegetacion()
  pesos_veg <- crear_matriz_pesos(datos_vegetacion, "vecindad")
  
  moran_ndvi <- calcular_moran_global(datos_vegetacion$ndvi, pesos_veg)
  correlacion_ndvi_precip <- cor(datos_vegetacion$ndvi, datos_vegetacion$precipitacion)
  
  cat("Moran's I NDVI:", round(moran_ndvi$estimate[1], 3), 
      "p-value:", round(moran_ndvi$p.value, 4), "\n")
  cat("Correlación NDVI-Precipitación:", round(correlacion_ndvi_precip, 3), "\n")
  
  resultados_comparativos$vegetacion <- list(
    moran_ndvi = moran_ndvi,
    correlacion_precip = correlacion_ndvi_precip,
    lisa_ndvi = calcular_lisa(datos_vegetacion$ndvi, pesos_veg),
    getis_ndvi = calcular_getis_ord(datos_vegetacion$ndvi, datos_vegetacion)
  )
  
  cat("\n=== ANÁLISIS COSTERO (Lambadri et al. 2025) ===\n")
  datos_costeros <- simular_datos_costeros()
  pesos_costa <- crear_matriz_pesos(datos_costeros, "vecindad")
  
  moran_exposicion <- calcular_moran_global(datos_costeros$exposicion, pesos_costa)
  cat("Moran's I Exposición:", round(moran_exposicion$estimate[1], 3),
      "p-value:", round(moran_exposicion$p.value, 4), "\n")
  
  resultados_comparativos$costeros <- list(
    moran_exposicion = moran_exposicion,
    lisa_exposicion = calcular_lisa(datos_costeros$exposicion, pesos_costa),
    getis_exposicion = calcular_getis_ord(datos_costeros$exposicion, datos_costeros)
  )
  
  cat("\n=== ANÁLISIS EPIDEMIOLÓGICO (Hu et al. 2025) ===\n")
  datos_epidemiologicos <- simular_datos_epidemiologicos()
  pesos_epi <- crear_matriz_pesos(datos_epidemiologicos, "vecindad")
  
  moran_paperas <- calcular_moran_global(datos_epidemiologicos$incidencia_paperas, pesos_epi)
  correlacion_dependencia <- cor(datos_epidemiologicos$incidencia_paperas, 
                                 datos_epidemiologicos$tasa_dependencia_infantil)
  
  cat("Moran's I Paperas:", round(moran_paperas$estimate[1], 3),
      "p-value:", round(moran_paperas$p.value, 4), "\n")
  cat("Correlación con tasa dependencia infantil:", round(correlacion_dependencia, 3), "\n")
  
  resultados_comparativos$epidemiologicos <- list(
    moran_paperas = moran_paperas,
    lisa_paperas = calcular_lisa(datos_epidemiologicos$incidencia_paperas, pesos_epi),
    getis_paperas = calcular_getis_ord(datos_epidemiologicos$incidencia_paperas, datos_epidemiologicos),
    correlacion_dependencia = correlacion_dependencia
  )
  
  return(resultados_comparativos)
}

# 5. VISUALIZACIONES BÁSICAS ----
visualizar_con_ggplot <- function() {
  
  datos_vegetacion <- simular_datos_vegetacion()
  datos_costeros <- simular_datos_costeros()
  datos_epidemiologicos <- simular_datos_epidemiologicos()
  
  # Convertir a data frames para ggplot
  datos_veg_df <- cbind(st_drop_geometry(datos_vegetacion), 
                        st_coordinates(st_centroid(datos_vegetacion)))
  
  datos_costa_df <- cbind(st_drop_geometry(datos_costeros), 
                          st_coordinates(st_centroid(datos_costeros)))
  
  datos_epi_df <- cbind(st_drop_geometry(datos_epidemiologicos), 
                        st_coordinates(st_centroid(datos_epidemiologicos)))
  
  # Mapa 1: NDVI
  p1 <- ggplot(datos_veg_df, aes(x = X, y = Y, fill = ndvi)) +
    geom_tile() +
    viridis::scale_fill_viridis(option = "viridis", name = "NDVI") +
    ggtitle("Vegetación - Yan et al. (2025)") +
    theme_minimal() +
    theme(axis.title = element_blank())
  
  # Mapa 2: Exposición costera
  p2 <- ggplot(datos_costa_df, aes(x = X, y = Y, fill = exposicion)) +
    geom_tile() +
    viridis::scale_fill_viridis(option = "plasma", name = "Índice Exposición") +
    ggtitle("Exposición Costera - Lambadri et al. (2025)") +
    theme_minimal() +
    theme(axis.title = element_blank())
  
  # Mapa 3: Incidencia paperas
  p3 <- ggplot(datos_epi_df, aes(x = X, y = Y, fill = incidencia_paperas)) +
    geom_tile() +
    viridis::scale_fill_viridis(option = "inferno", name = "Incidencia Paperas") +
    ggtitle("Epidemiología - Hu et al. (2025)") +
    theme_minimal() +
    theme(axis.title = element_blank())
  
  # Mostrar mapas
  print(p1)
  print(p2)
  print(p3)
  
  return(list(p1, p2, p3))
}

# 6. ANÁLISIS COMPARATIVO AVANZADO ----
analisis_comparativo_avanzado <- function(resultados) {
  
  cat("\n\nANÁLISIS COMPARATIVO AVANZADO")
  cat("\n=============================\n")
  
  # 6.1 Comparación de distribuciones
  comparar_distribuciones <- function() {
    
    datos_veg <- simular_datos_vegetacion()
    datos_costa <- simular_datos_costeros()
    datos_epi <- simular_datos_epidemiologicos()
    
    n <- nrow(datos_veg)
    
    comparacion_df <- data.frame(
      Valor = c(scale(datos_veg$ndvi), scale(datos_costa$exposicion), scale(datos_epi$incidencia_paperas)),
      Estudio = rep(c("Vegetación", "Costero", "Epidemiológico"), each = n),
      Variable = rep(c("NDVI", "Exposición", "Paperas"), each = n)
    )
    
    p_boxplot <- ggplot(comparacion_df, aes(x = Estudio, y = Valor, fill = Estudio)) +
      geom_boxplot(alpha = 0.7) +
      geom_jitter(alpha = 0.3, width = 0.2) +
      scale_fill_manual(values = c("Vegetación" = "#2E8B57", 
                                   "Costero" = "#4682B4", 
                                   "Epidemiológico" = "#DC143C")) +
      labs(title = "Distribución Comparativa de Variables por Estudio",
           y = "Valor Estandarizado", x = "") +
      theme_minimal() +
      theme(legend.position = "none")
    
    print(p_boxplot)
    
    return(comparacion_df)
  }
  
  # 6.2 Matriz de correlaciones espaciales
  analizar_correlaciones_espaciales <- function() {
    
    datos_epi <- simular_datos_epidemiologicos()
    
    vars_cor <- st_drop_geometry(datos_epi)[, c("incidencia_paperas", 
                                                "tasa_dependencia_infantil", 
                                                "pib_per_capita",
                                                "cobertura_vacunacion",
                                                "densidad_poblacional")]
    
    cor_matrix <- cor(vars_cor)
    cor_melt <- reshape2::melt(cor_matrix)
    
    p_cor <- ggplot(cor_melt, aes(x = Var1, y = Var2, fill = value)) +
      geom_tile(color = "white") +
      geom_text(aes(label = round(value, 2)), color = "black", size = 4) +
      scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                           midpoint = 0, limit = c(-1, 1), space = "Lab",
                           name = "Correlación") +
      labs(title = "Matriz de Correlación - Factores Epidemiológicos (Hu et al.)",
           x = "", y = "") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1))
    
    print(p_cor)
    
    return(cor_matrix)
  }
  
  # 6.3 Análisis temporal simulado
  analisis_temporal_simulado <- function() {
    
    tiempo <- 2000:2020
    ndvi_temporal <- 0.5 + 0.3 * sin((tiempo-2000)/3) + 0.1 * rnorm(length(tiempo))
    precipitacion_temporal <- ndvi_temporal * 0.8 + 0.1 * rnorm(length(tiempo))
    
    serie_df <- data.frame(
      Tiempo = rep(tiempo, 2),
      Valor = c(ndvi_temporal, precipitacion_temporal),
      Variable = rep(c("NDVI", "Precipitación"), each = length(tiempo))
    )
    
    p_serie <- ggplot(serie_df, aes(x = Tiempo, y = Valor, color = Variable)) +
      geom_line(size = 1) +
      geom_point(size = 2) +
      scale_color_manual(values = c("NDVI" = "#2E8B57", "Precipitación" = "#4682B4")) +
      labs(title = "Simulación de Series Temporales - Vegetación (Yan et al.)",
           y = "Valor Normalizado", x = "Año") +
      theme_minimal() +
      theme(legend.position = "bottom")
    
    print(p_serie)
    
    return(serie_df)
  }
  
  # 6.4 Mapas de densidad
  crear_mapas_densidad <- function() {
    
    datos_veg <- simular_datos_vegetacion()
    datos_epi <- simular_datos_epidemiologicos()
    
    coords_veg <- st_coordinates(st_centroid(datos_veg))
    coords_epi <- st_coordinates(st_centroid(datos_epi))
    
    densidad_df <- data.frame(
      X = c(coords_veg[,1], coords_epi[,1]),
      Y = c(coords_veg[,2], coords_epi[,2]),
      Valor = c(datos_veg$ndvi, datos_epi$incidencia_paperas),
      Tipo = rep(c("NDVI", "Paperas"), each = nrow(datos_veg))
    )
    
    p_densidad <- ggplot(densidad_df, aes(x = X, y = Y)) +
      geom_density_2d_filled(alpha = 0.7) +
      facet_wrap(~ Tipo, ncol = 2) +
      labs(title = "Mapas de Densidad Espacial Comparativos",
           x = "Longitud", y = "Latitud") +
      theme_minimal() +
      theme(legend.position = "none")
    
    print(p_densidad)
    
    return(densidad_df)
  }
  
  # 6.5 Análisis de sensibilidad
  analisis_sensibilidad_pesos <- function() {
    
    datos_epi <- simular_datos_epidemiologicos()
    
    tipos_pesos <- c("vecindad", "knn", "distancia")
    resultados_sensibilidad <- tibble()
    
    for(tipo in tipos_pesos) {
      if(tipo == "knn") {
        pesos <- crear_matriz_pesos(datos_epi, tipo, k = 4)
      } else {
        pesos <- crear_matriz_pesos(datos_epi, tipo)
      }
      
      moran <- calcular_moran_global(datos_epi$incidencia_paperas, pesos)
      
      fila <- tibble(
        Matriz_Pesos = tipo,
        Morans_I = round(moran$estimate[1], 3),
        P_valor = round(moran$p.value, 4),
        Significancia = ifelse(moran$p.value < 0.05, "***", "NS")
      )
      
      resultados_sensibilidad <- bind_rows(resultados_sensibilidad, fila)
    }
    
    p_sensibilidad <- ggplot(resultados_sensibilidad, aes(x = Matriz_Pesos, y = Morans_I, fill = Matriz_Pesos)) +
      geom_col(alpha = 0.7) +
      geom_text(aes(label = paste("I =", Morans_I)), vjust = -0.5, size = 4) +
      scale_fill_brewer(palette = "Set1") +
      labs(title = "Sensibilidad del Moran's I a Diferentes Matrices de Pesos",
           y = "Moran's I", x = "Tipo de Matriz de Pesos") +
      theme_minimal() +
      theme(legend.position = "none")
    
    print(p_sensibilidad)
    
    cat("Análisis de Sensibilidad:\n")
    print(knitr::kable(resultados_sensibilidad, format = "simple"))
    
    return(resultados_sensibilidad)
  }
  
  # 6.6 Comparación de clusters entre estudios (corregido: usar bind_rows para evitar rbind con columnas distintas)
  comparar_clusters_estudios <- function() {
    
    datos_veg <- simular_datos_vegetacion()
    datos_costa <- simular_datos_costeros()
    datos_epi <- simular_datos_epidemiologicos()
    
    # Calcular LISA para cada estudio y clasificar
    calcular_y_clasificar <- function(datos, variable, nombre_estudio) {
      pesos <- crear_matriz_pesos(datos)
      lisa <- calcular_lisa(datos[[variable]], pesos)
      
      datos$lisa_pval <- lisa[,5]
      datos$lisa_i <- lisa[,1]
      
      datos$cluster <- "No significativo"
      datos$cluster[datos$lisa_pval < 0.05 & datos$lisa_i > 0] <- "Alto-Alto"
      datos$cluster[datos$lisa_pval < 0.05 & datos$lisa_i < 0] <- "Bajo-Bajo"
      datos$Estudio <- nombre_estudio
      
      return(datos)
    }
    
    datos_veg <- calcular_y_clasificar(datos_veg, "ndvi", "Vegetación")
    datos_costa <- calcular_y_clasificar(datos_costa, "exposicion", "Costero")
    datos_epi <- calcular_y_clasificar(datos_epi, "incidencia_paperas", "Epidemiológico")
    
    # Combinar datos (aseguramos columnas homogéneas y convertir a data.frame)
    combinar_datos <- function(datos) {
      coords <- st_coordinates(st_centroid(datos))
      df <- cbind(st_drop_geometry(datos), coords)
      # garantizar el mismo orden/columnas útiles
      df <- df %>% select(id, Estudio, cluster, everything())
      return(as.data.frame(df))
    }
    
    clusters_combinados <- bind_rows(
      combinar_datos(datos_veg),
      combinar_datos(datos_costa),
      combinar_datos(datos_epi)
    )
    
    p_clusters_comp <- ggplot(clusters_combinados, aes(x = X, y = Y, fill = cluster)) +
      geom_tile() +
      facet_wrap(~ Estudio, ncol = 3) +
      scale_fill_manual(values = c("Alto-Alto" = "red", "Bajo-Bajo" = "blue", 
                                   "No significativo" = "lightgray"),
                        name = "Clusters LISA") +
      labs(title = "Comparación de Clusters LISA entre los Tres Estudios",
           x = "", y = "") +
      theme_minimal() +
      theme(axis.text = element_blank(),
            axis.ticks = element_blank())
    
    print(p_clusters_comp)
    
    resumen_clusters <- table(clusters_combinados$Estudio, clusters_combinados$cluster)
    cat("\nResumen de Clusters por Estudio:\n")
    print(resumen_clusters)
    
    return(clusters_combinados)
  }
  
  # 6.7 Heatmap de indicadores globales
  crear_heatmap_indicadores <- function(resultados) {
    
    indicadores_df <- data.frame(
      Estudio = c("Vegetación", "Costero", "Epidemiológico"),
      Moran_I = c(
        resultados$vegetacion$moran_ndvi$estimate[1],
        resultados$costeros$moran_exposicion$estimate[1],
        resultados$epidemiologicos$moran_paperas$estimate[1]
      ),
      Correlación = c(
        resultados$vegetacion$correlacion_precip,
        NA,
        resultados$epidemiologicos$correlacion_dependencia
      ),
      Significancia = c(
        -log10(resultados$vegetacion$moran_ndvi$p.value),
        -log10(resultados$costeros$moran_exposicion$p.value),
        -log10(resultados$epidemiologicos$moran_paperas$p.value)
      )
    )
    
    indicadores_melt <- reshape2::melt(indicadores_df, id.vars = "Estudio")
    
    p_heatmap <- ggplot(indicadores_melt, aes(x = variable, y = Estudio, fill = value)) +
      geom_tile(color = "white") +
      geom_text(aes(label = round(value, 2)), color = "black", size = 4) +
      viridis::scale_fill_viridis(name = "Valor") +
      labs(title = "Heatmap de Indicadores por Estudio",
           x = "Indicador", y = "Estudio") +
      theme_minimal()
    
    print(p_heatmap)
    
    return(indicadores_df)
  }
  
  # Ejecutar todos los análisis avanzados
  cat("\n1. COMPARACIÓN DE DISTRIBUCIONES\n")
  dist_comparativa <- comparar_distribuciones()
  
  cat("\n2. ANÁLISIS DE CORRELACIONES\n")
  cor_matrix <- analizar_correlaciones_espaciales()
  
  cat("\n3. ANÁLISIS TEMPORAL SIMULADO\n")
  serie_temporal <- analisis_temporal_simulado()
  
  cat("\n4. MAPAS DE DENSIDAD\n")
  mapas_densidad <- crear_mapas_densidad()
  
  cat("\n5. ANÁLISIS DE SENSIBILIDAD\n")
  sensibilidad <- analisis_sensibilidad_pesos()
  
  cat("\n6. COMPARACIÓN DE CLUSTERS\n")
  clusters_comparativos <- comparar_clusters_estudios()
  
  cat("\n7. HEATMAP DE INDICADORES\n")
  heatmap_indicadores <- crear_heatmap_indicadores(resultados)
  
  return(list(
    distribuciones = dist_comparativa,
    correlaciones = cor_matrix,
    series_temporales = serie_temporal,
    densidad = mapas_densidad,
    sensibilidad = sensibilidad,
    clusters = clusters_comparativos,
    heatmap = heatmap_indicadores
  ))
}

# 7. FUNCIONES DE REPORTE ----
crear_tabla_comparativa <- function(resultados) {
  
  tabla_comparativa <- data.frame(
    Estudio = c("Vegetación (Yan)", "Costero (Lambadri)", "Epidemiológico (Hu)"),
    Variable = c("NDVI", "Índice Exposición", "Incidencia Paperas"),
    Morans_I = c(
      round(resultados$vegetacion$moran_ndvi$estimate[1], 3),
      round(resultados$costeros$moran_exposicion$estimate[1], 3),
      round(resultados$epidemiologicos$moran_paperas$estimate[1], 3)
    ),
    P_valor = c(
      round(resultados$vegetacion$moran_ndvi$p.value, 4),
      round(resultados$costeros$moran_exposicion$p.value, 4),
      round(resultados$epidemiologicos$moran_paperas$p.value, 4)
    ),
    Significancia = c(
      ifelse(resultados$vegetacion$moran_ndvi$p.value < 0.05, "***", "NS"),
      ifelse(resultados$costeros$moran_exposicion$p.value < 0.05, "***", "NS"),
      ifelse(resultados$epidemiologicos$moran_paperas$p.value < 0.05, "***", "NS")
    ),
    Correlación_Principal = c(
      round(resultados$vegetacion$correlacion_precip, 3),
      NA,
      round(resultados$epidemiologicos$correlacion_dependencia, 3)
    )
  )
  
  print(knitr::kable(tabla_comparativa, format = "simple", 
                     caption = "Comparación de Autocorrelación Espacial Global"))
  
  return(tabla_comparativa)
}

# 8. ANÁLISIS DE CLUSTERS LISA ----
analizar_clusters_lisa <- function() {
  
  datos_epi <- simular_datos_epidemiologicos()
  pesos <- crear_matriz_pesos(datos_epi)
  lisa <- calcular_lisa(datos_epi$incidencia_paperas, pesos)
  
  # Identificar clusters significativos
  datos_epi$lisa_i <- lisa[,1]
  datos_epi$lisa_pval <- lisa[,5]
  
  # Clasificar clusters
  datos_epi$cluster <- "No significativo"
  datos_epi$cluster[datos_epi$lisa_pval < 0.05 & datos_epi$lisa_i > 0] <- "Alto-Alto"
  datos_epi$cluster[datos_epi$lisa_pval < 0.05 & datos_epi$lisa_i < 0] <- "Bajo-Bajo"
  
  # Visualizar clusters LISA
  datos_epi_df <- cbind(st_drop_geometry(datos_epi), 
                        st_coordinates(st_centroid(datos_epi)))
  
  p_lisa <- ggplot(datos_epi_df, aes(x = X, y = Y, fill = cluster)) +
    geom_tile() +
    scale_fill_manual(values = c("Alto-Alto" = "red", "Bajo-Bajo" = "blue", 
                                 "No significativo" = "lightgray"),
                      name = "Clusters LISA") +
    ggtitle("Clusters LISA - Incidencia de Paperas (Hu et al. 2025)") +
    theme_minimal() +
    theme(axis.title = element_blank())
  
  print(p_lisa)
  
  cat("Resumen clusters LISA:\n")
  print(table(datos_epi$cluster))
  
  return(datos_epi)
}

# 9. EJECUCIÓN PRINCIPAL ----
cat("INICIANDO ANÁLISIS COMPARATIVO DE AUTOCORRELACIÓN ESPACIAL\n")
cat("===========================================================\n\n")

# Análisis básico
resultados <- realizar_analisis_comparativo()

cat("\n\nRESUMEN COMPARATIVO\n")
cat("===================\n")
tabla_final <- crear_tabla_comparativa(resultados)

cat("\n\nGENERANDO VISUALIZACIONES BÁSICAS\n")
cat("================================\n")
mapas <- visualizar_con_ggplot()

cat("\n\nANÁLISIS DE CLUSTERS LISA\n")
cat("========================\n")
clusters_lisa <- analizar_clusters_lisa()

# Análisis avanzado
cat("\n\nEJECUTANDO ANÁLISIS COMPARATIVO AVANZADO\n")
cat("=========================================\n")
resultados_avanzados <- analisis_comparativo_avanzado(resultados)

# 10. REPORTE FINAL (tabla resumen)
resumen_estadistico <- data.frame(
  Estudio = c("Yan et al. (Vegetación)", "Lambadri et al. (Costero)", "Hu et al. (Epidemiológico)"),
  Moran_I = c(
    round(resultados$vegetacion$moran_ndvi$estimate[1], 3),
    round(resultados$costeros$moran_exposicion$estimate[1], 3),
    round(resultados$epidemiologicos$moran_paperas$estimate[1], 3)
  ),
  Fuerza_Autocorrelacion = c(
    "Alta (I > 0.6)",
    "Muy Alta (I > 0.8)", 
    "Moderada-Alta (I > 0.6)"
  ),
  Tipo_Analisis = c(
    "Bivariante + Series Temporales",
    "Univariante + Validación Campo",
    "Multivariante + Geodetector"
  ),
  Principal_Aporte = c(
    "Relación clima-vegetación",
    "Gestión riesgo costero",
    "Factores determinantes salud"
  ),
  Metodología_Espacial = c(
    "Moran + LISA + Correlación",
    "Moran + LISA + Permutaciones", 
    "Moran + LISA + Getis-Ord + Geodetector"
  )
)

print(knitr::kable(resumen_estadistico, format = "simple", 
                   caption = "Resumen Comparativo Final de los Tres Estudios"))

# 11. EXPORTACIÓN DE RESULTADOS ----
write.csv(tabla_final, "comparacion_autocorrelacion_espacial.csv", row.names = FALSE)
write.csv(resultados_avanzados$distribuciones, "distribuciones_comparativas.csv", row.names = FALSE)
write.csv(resultados_avanzados$sensibilidad, "analisis_sensibilidad.csv", row.names = FALSE)
write.csv(resultados_avanzados$clusters, "clusters_comparativos.csv", row.names = FALSE)

# 12. RESUMEN EJECUTIVO ----
cat("\n\n🎯 RESUMEN EJECUTIVO DEL ANÁLISIS COMPARATIVO\n")
cat("=============================================\n")
cat("✅ ANÁLISIS COMPLETADO EXITOSAMENTE!\n\n")
cat("📊 RESULTADOS PRINCIPALES:\n")
cat("   • Todos los estudios muestran autocorrelación espacial (siempre verifique p-valor)\n")
cat("\n📈 ARCHIVOS GENERADOS:\n")
cat("   • comparacion_autocorrelacion_espacial.csv\n")
cat("   • distribuciones_comparativas.csv\n")
cat("   • analisis_sensibilidad.csv\n")
cat("   • clusters_comparativos.csv\n\n")

cat("FIN DEL PROCESO.\n")

